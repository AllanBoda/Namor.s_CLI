const axios = require('axios');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

const projectPath = './sample_project';
const projectName = 'SampleProject';

async function sendMetrics() {
  try {
    const commands = [
      `node bin/cli.js loc ${projectPath} --json`,
      `node bin/cli.js comments ${projectPath} --json`,
      `node bin/cli.js ratio ${projectPath} --json`,
      `node bin/cli.js deps ${projectPath} --json`,
      `node bin/cli.js visibility ${projectPath} --json`
    ];
    for (const command of commands) {
      const { stdout, stderr } = await execPromise(command);
      if (stderr) throw new Error(stderr);
      console.log(`Saída bruta para ${command}:\n${stdout}`); // Depuração da saída bruta
      const lines = stdout.trim().split('\n').filter(line => line.trim().length > 0); // Remove linhas vazias
      let jsonLine = lines.find(line => {
        try {
          const parsed = JSON.parse(line.trim()); // Remove espaços extras
          console.log(`Linha testada: "${line.trim()}" -> Parsed: ${JSON.stringify(parsed)}`); // Depuração
          return parsed && typeof parsed === 'object'; // Aceita qualquer objeto, mesmo vazio
        } catch (e) {
          console.log(`Linha rejeitada: "${line.trim()}" -> Erro: ${e.message}`); // Depuração
          return false;
        }
      });
      if (!jsonLine) {
        console.warn(`Aviso: Nenhum JSON válido encontrado para comando ${command}. Pulando...`);
        continue;
      }
      const result = JSON.parse(jsonLine);
      if (result.error) {
        console.warn(`Aviso: Erro detectado em ${command}: ${result.error}. Pulando...`);
        continue;
      }
      let metricType, metricValue;
      if (command.includes('loc')) { metricType = 'linesOfCode'; metricValue = { total: result.linesOfCode }; }
      else if (command.includes('comments')) { metricType = 'commentLines'; metricValue = { total: result.commentLines }; }
      else if (command.includes('ratio')) { metricType = 'commentRatio'; metricValue = result; }
      else if (command.includes('deps')) { metricType = 'dependencies'; metricValue = result; }
      else if (command.includes('visibility')) { metricType = 'methodVisibility'; metricValue = result; }
      await axios.post('http://localhost:3000/metrics', { projectName, metricType, metricValue });
      console.log(`Enviada ${metricType} para ${projectName}`);
    }
  } catch (error) {
    console.error('Erro ao enviar métricas:', error.message);
  }
}

sendMetrics();