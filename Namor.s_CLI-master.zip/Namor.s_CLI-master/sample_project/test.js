// Exemplo de código
function hello() {
    console.log('Hello');
  } // Fechado corretamente
  class Test {
    #privateMethod() {}
    publicMethod() {}
  }