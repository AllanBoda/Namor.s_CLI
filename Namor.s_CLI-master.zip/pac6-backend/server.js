const express = require('express');
const mysql = require('mysql2/promise');
const Redis = require('ioredis');
const schedule = require('node-schedule');
const app = express();

app.use(express.json());

const dbConfig = {
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'pac6_db'
};

const redis = new Redis();

async function initializeDatabase() {
  const db = await mysql.createConnection({
    host: dbConfig.host,
    user: dbConfig.user,
    password: dbConfig.password
  });
  await db.execute('CREATE DATABASE IF NOT EXISTS pac6_db');
  await db.end();

  const dbWithSchema = await mysql.createConnection(dbConfig);
  await dbWithSchema.execute(`
    CREATE TABLE IF NOT EXISTS projects (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE (name)
    )
  `);
  await dbWithSchema.execute(`
    CREATE TABLE IF NOT EXISTS metrics (
      id INT AUTO_INCREMENT PRIMARY KEY,
      project_id INT NOT NULL,
      metric_type VARCHAR(50) NOT NULL,
      metric_value JSON NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      hash VARCHAR(255) NOT NULL,
      FOREIGN KEY (project_id) REFERENCES projects(id),
      UNIQUE (hash)
    )
  `);
  await dbWithSchema.end();
}

async function processMetricQueue() {
  const db = await mysql.createConnection(dbConfig);
  while (true) {
    const job = await redis.brpop('metric_queue', 0);
    const metricData = JSON.parse(job[1]);
    try {
      await db.beginTransaction();
      let [project] = await db.query('SELECT id FROM projects WHERE name = ?', [metricData.projectName]);
      if (!project.length) {
        const [result] = await db.query('INSERT INTO projects (name) VALUES (?)', [metricData.projectName]);
        project = [{ id: result.insertId }];
      }
      const projectId = project[0].id;
      const hash = require('crypto').createHash('md5')
        .update(JSON.stringify({ projectId, metricType: metricData.metricType, metricValue: metricData.metricValue }))
        .digest('hex');
      await db.query(
        'INSERT INTO metrics (project_id, metric_type, metric_value, hash) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE created_at = CURRENT_TIMESTAMP',
        [projectId, metricData.metricType, JSON.stringify(metricData.metricValue), hash]
      );
      await db.query('UPDATE projects SET last_updated = CURRENT_TIMESTAMP WHERE id = ?', [projectId]);
      await db.commit();
    } catch (error) {
      await db.rollback();
      console.error('Erro ao processar métrica:', error.message);
    }
  }
}

function scheduleCleanupJob() {
  schedule.scheduleJob('0 0 * * *', async () => {
    const db = await mysql.createConnection(dbConfig);
    try {
      const [inactiveProjects] = await db.query(
        'SELECT id FROM projects WHERE last_updated < DATE_SUB(NOW(), INTERVAL 7 DAY)'
      );
      for (const project of inactiveProjects) {
        await db.beginTransaction();
        await db.query('DELETE FROM metrics WHERE project_id = ?', [project.id]);
        await db.query('DELETE FROM projects WHERE id = ?', [project.id]);
        await db.commit();
        console.log(`Projeto inativo ID ${project.id} deletado`);
      }
    } catch (error) {
      console.error('Erro durante a limpeza:', error.message);
    } finally {
      await db.end();
    }
  });
}

app.post('/metrics', async (req, res) => {
  const { projectName, metricType, metricValue } = req.body;
  if (!projectName || !metricType || !metricValue) {
    return res.status(400).json({ error: 'Campos obrigatórios ausentes' });
  }
  await redis.lpush('metric_queue', JSON.stringify({ projectName, metricType, metricValue }));
  res.status(202).json({ message: 'Métrica recebida e enfileirada para processamento' });
});

app.get('/metrics/:projectName', async (req, res) => {
  const projectName = req.params.projectName;
  const db = await mysql.createConnection(dbConfig);
  try {
    const [project] = await db.query('SELECT id FROM projects WHERE name = ?', [projectName]);
    if (!project.length) {
      return res.status(404).json({ error: 'Projeto não encontrado' });
    }
    const projectId = project[0].id;
    const [metrics] = await db.query(
      'SELECT metric_type, metric_value, created_at FROM metrics WHERE project_id = ? ORDER BY created_at DESC',
      [projectId]
    );
    const formattedMetrics = metrics.map(metric => ({
      metricType: metric.metric_type,
      metricValue: JSON.parse(metric.metric_value),
      timestamp: metric.created_at
    }));
    res.status(200).json(formattedMetrics);
  } catch (error) {
    res.status(500).json({ error: error.message });
  } finally {
    await db.end();
  }
});

const PORT = 3000;
app.listen(PORT, async () => {
  console.log(`Servidor rodando na porta ${PORT}`);
  await initializeDatabase();
  processMetricQueue();
  scheduleCleanupJob();
});