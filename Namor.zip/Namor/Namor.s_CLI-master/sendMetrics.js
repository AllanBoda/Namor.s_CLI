const axios = require('axios').create({
  timeout: 5000,
  maxRedirects: 5
});
const { countLOC, analyzeDependencies, calculateCommentRatio, analyzeMethodVisibility, countComments } = require('./lib');

const projectPath = process.argv[2] || './sample_project';
const projectName = process.argv[3] || 'SampleProject';

async function sendMetrics() {
  try {
    const commands = [
      { type: 'linesOfCode', fn: countLOC, key: 'linesOfCode', transform: total => ({ total }) },
      { type: 'commentLines', fn: countComments, key: 'commentLines', transform: total => ({ total }) },
      { type: 'commentRatio', fn: calculateCommentRatio, key: 'commentRatio', transform: result => result },
      { type: 'dependencies', fn: analyzeDependencies, key: 'dependencies', transform: result => result },
      { type: 'methodVisibility', fn: analyzeMethodVisibility, key: 'methodVisibility', transform: result => result }
    ];

    for (const { type, fn, key, transform } of commands) {
      try {
        const result = await fn(projectPath);
        if (result.error) {
          console.warn(`Aviso: Erro em ${type}: ${result.error}. Pulando...`);
          continue;
        }
        const metricValue = transform(result);
        await axios.post('http://localhost:3000/metrics', { projectName, metricType: type, metricValue });
        console.log(`Enviada ${type} para ${projectName}`);
      } catch (err) {
        console.warn(`Erro ao processar ${type}: ${err.message}`);
      }
    }
  } catch (error) {
    console.error('Erro ao enviar métricas:', error.message);
  }
}

sendMetrics();