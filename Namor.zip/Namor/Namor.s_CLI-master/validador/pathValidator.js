const fs = require('fs').promises;
const path = require('path');

async function validatePath(filePath) {
  try {
    await fs.access(filePath);
    return await fs.stat(filePath);
  } catch {
    throw new Error(`Caminho inválido: ${filePath}`);
  }
}

async function processPath(filePath, processFile, aggregateResults) {
  const validExtensions = process.env.VALID_EXTENSIONS?.split(',') || ['.js'];
  const stats = await validatePath(filePath);

  if (stats.isDirectory()) {
    const files = await fs.readdir(filePath);
    const results = await Promise.all(
      files
        .filter(file => validExtensions.includes(path.extname(file)))
        .map(async file => {
          try {
            return await processPath(path.join(filePath, file), processFile, aggregateResults);
          } catch (err) {
            console.warn(`Erro ao processar ${file}: ${err.message}`);
            return null;
          }
        })
    );
    return aggregateResults(results.filter(result => result !== null));
  }

  return processFile(filePath);
}

module.exports = { validatePath, processPath };