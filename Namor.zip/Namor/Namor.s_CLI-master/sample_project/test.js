// Exemplo de código
function hello() {
  console.log('Hello');
}

function complexFunction(x) {
  if (x > 0) {
      for (let i = 0; i < x; i++) {
          console.log(i);
      }
  } else {
      console.log('Negative');
  }
}

const unusedVar = 42; // Para testar deadCodeDetector

function duplicatedCode() {
  console.log('This is duplicated');
  return 42;
}

function anotherDuplicatedCode() {
  console.log('This is duplicated');
  return 42;
}

class Test {
  #privateMethod() {
      console.log('Private');
  }
  publicMethod() {
      console.log('Public');
  }
}

export function testModule() {
  console.log('Test ES Module');
}