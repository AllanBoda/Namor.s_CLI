# Namor's CLI: Ferramenta para Análise de Código JavaScript

Esta ferramenta CLI (Command Line Interface) foi desenvolvida como parte do projeto da 6ª fase do PAC, com o objetivo de auxiliar no ciclo de manutenção e qualidade de código JavaScript. Ela oferece um conjunto de análises estáticas para fornecer insights sobre a estrutura, complexidade e possíveis problemas no código.

## Funcionalidades Implementadas

A ferramenta CLI oferece as seguintes funcionalidades de análise de código:

### 1. Contagem de Linhas de Código (LOC)

Conta o número total de linhas de código em um arquivo ou diretório especificado. Isso inclui linhas de código, linhas em branco e linhas de comentários.

**Uso:**
```bash
node cli.js loc <path>
```
**Exemplo:**
```bash
node cli.js loc ./src
node cli.js loc ./src/myFile.js --json
```

### 2. Análise de Estrutura

Identifica e conta funções e classes em um arquivo ou diretório. Fornece uma visão geral da organização estrutural do código.

**Uso:**
```bash
node cli.js analyze <path>
```
**Exemplo:**
```bash
node cli.js analyze ./src
```

### 3. Contagem de Comentários

Conta o número de linhas dedicadas a comentários em um arquivo ou diretório. Útil para avaliar a documentação interna do código.

**Uso:**
```bash
node cli.js comments <path>
```
**Exemplo:**
```bash
node cli.js comments ./src
```

### 4. Análise de Indentação

Analisa os níveis de indentação em um arquivo ou diretório, permitindo verificar a consistência do estilo de código. Pode-se definir o tamanho do tab para a análise.

**Uso:**
```bash
node cli.js indent <path> [--tab-size <size>]
```
**Exemplo:**
```bash
node cli.js indent ./src --tab-size 2
```

### 5. Análise de Dependências

Analisa as dependências de módulos em um arquivo ou diretório, identificando tanto dependências locais quanto externas. Ajuda a entender o acoplamento do código.

**Uso:**
```bash
node cli.js deps <path>
```
**Exemplo:**
```bash
node cli.js deps ./src
```

### 6. Proporção de Comentários

Calcula a proporção de linhas de comentários em relação ao total de linhas de código. Um indicador da legibilidade e manutenibilidade do código.

**Uso:**
```bash
node cli.js ratio <path>
```
**Exemplo:**
```bash
node cli.js ratio ./src
```

### 7. Análise de Visibilidade de Métodos

Conta métodos públicos e privados em um arquivo ou diretório. Relevante para linguagens que suportam modificadores de acesso, ajudando a reforçar princípios de encapsulamento.

**Uso:**
```bash
node cli.js visibility <path>
```
**Exemplo:**
```bash
node cli.js visibility ./src
```

### 8. Tamanho Médio das Funções

Calcula o tamanho médio das funções (em linhas de código) em um arquivo ou diretório. Funções muito grandes podem indicar baixa coesão e dificuldade de manutenção.

**Uso:**
```bash
node cli.js avg-func-size <path>
```
**Exemplo:**
```bash
node cli.js avg-func-size ./src
```

### 9. Identificação de Código Duplicado

Identifica trechos de código duplicados em um arquivo ou diretório. A duplicação de código é um problema comum que pode levar a bugs e dificultar a manutenção.

**Uso:**
```bash
node cli.js duplicate-code <path>
```
**Exemplo:**
```bash
node cli.js duplicate-code ./src
```

### 10. Predição de Bugs com IA (Simulado)

Submete trechos de código para uma API de LLM (simulada neste projeto) solicitando sugestões de melhoria e indicações de problemas. Em um cenário real, esta funcionalidade se integraria a um serviço de IA para análise avançada.

**Uso:**
```bash
node cli.js predict-bugs <path>
```
**Exemplo:**
```bash
node cli.js predict-bugs ./src/myFile.js
```

### 11. Análise Assintótica das Funções (Heurística)

Realiza uma análise heurística da complexidade assintótica das funções em um arquivo ou diretório. Esta é uma simplificação para indicar o comportamento da complexidade de um algoritmo conforme o tamanho da entrada cresce, baseada em contagem de operações e profundidade de aninhamento.

**Uso:**
```bash
node cli.js asymptotic-analysis <path>
```
**Exemplo:**
```bash
node cli.js asymptotic-analysis ./src
```

### 12. Identificação de Código Morto

Identifica funções e variáveis que são declaradas, mas nunca utilizadas no código. O código morto pode ser removido para melhorar a clareza e o desempenho.

**Uso:**
```bash
node cli.js dead-code <path>
```
**Exemplo:**
```bash
node cli.js dead-code ./src
```

### 13. Análise Ciclomática do Código

Calcula a complexidade ciclomática das funções em um arquivo ou diretório. A complexidade ciclomática é uma métrica de software que indica a complexidade lógica de um programa, baseada no número de caminhos independentes através do código.

**Uso:**
```bash
node cli.js cyclomatic-complexity <path>
```
**Exemplo:**
```bash
node cli.js cyclomatic-complexity ./src
```

## Estrutura do Projeto

- `bin/cli.js`: O ponto de entrada principal da ferramenta CLI, onde os comandos são definidos e as funções de análise são chamadas.
- `lib/`: Contém os módulos JavaScript que implementam as diferentes funcionalidades de análise de código.
- `tests/`: Contém os testes unitários para as funcionalidades implementadas.
- `validador/`: Contém módulos para validação de caminhos.
- `package.json`: Define as informações do projeto, scripts e dependências.

## Instalação e Execução

Para instalar as dependências do projeto, navegue até o diretório raiz do projeto e execute:

```bash
npm install
```

Para executar a ferramenta, use o comando `node bin/cli.js` seguido do comando de análise desejado e o caminho para o arquivo ou diretório a ser analisado.

## Contribuição

Sinta-se à vontade para contribuir com melhorias, novas análises ou correções de bugs. Para isso, siga os passos:

1. Faça um fork do repositório.
2. Crie uma nova branch para sua funcionalidade (`git checkout -b feature/nova-funcionalidade`).
3. Implemente suas mudanças e adicione testes unitários, se aplicável.
4. Certifique-se de que todos os testes passem.
5. Envie suas alterações (`git push origin feature/nova-funcionalidade`).
6. Abra um Pull Request.

## Licença

Este projeto está licenciado sob a licença ISC.


